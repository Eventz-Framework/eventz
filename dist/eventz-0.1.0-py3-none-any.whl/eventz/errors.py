class AggregateNotFound(Exception):
    pass


class EventValidationError(Exception):
    pass


class EventNotMatchedError(Exception):
    pass
